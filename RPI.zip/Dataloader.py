
import cv2
import os

DEVICE_FILE, DEVICE_CAM = range(0, 2)
class DataLoader(object) :
    

    def __init__(self, dev_type, **kwarg):

        self.dev_type = dev_type
        self.dataset_dir = None
        self.cam = None 
        self.init_params = kwarg 
        print(kwarg)

        self.__init_device(dev_type, **self.init_params)

    def __init_device(self, dev_type, **kwarg):
        
        print(kwarg)

        if dev_type == DEVICE_FILE:
           
           self.dataset_dir = kwarg.get('directory')     
           return self.dataset_dir

        elif dev_type == DEVICE_CAM:
            self.cam = 1
            self.cap = cv2.VideoCapture(0)


        else:
            raise  ValueError("Incorrect device type had been provided.")


    def __get_files(self):
        files_list = list()
    
        if self.dataset_dir:
            for file_path in os.listdir(self.dataset_dir):
                files_list.append(os.path.join(self.dataset_dir, file_path))
            for file_path in sorted(files_list):
                yield file_path

        elif self.cam:

            while(True):
                ret, frame = self.cap.read()
                yield frame

    def get_data_frame(self):
        
        if self.dataset_dir:
            try:
                for dataframe_path in self.__get_files():
                    yield cv2.imread(dataframe_path)
            except StopIteration:
                pass

        else:
            try:
                for dframe in self.__get_files():
                    yield dframe
    
            except StopIteration:
                self.cap.release()

