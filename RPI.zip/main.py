from Dataloader import DataLoader
import collections
import cv2
import numpy as np

    

#data = DataLoader(dev_type=0, directory='./Data/Picts')

data = DataLoader(dev_type=1)

deque = collections.deque(maxlen=50) 

counter = int(0)
COUNTER_MAX = 2

avaragage_frame = 0
avarage_frame_init = False

import time

for dframe in data.get_data_frame():
   
    cv2.imshow('Original', dframe)
    gray_scaled_frame = cv2.cvtColor(dframe, cv2.COLOR_BGR2GRAY)
    cv2.imshow('Color to grayscale', gray_scaled_frame)
    

    gaussian_blur_frame = cv2.GaussianBlur(gray_scaled_frame, (51,51), 0)
    cv2.imshow('Gaussian blur', gaussian_blur_frame)

    _, binary_frame = cv2.threshold(gaussian_blur_frame, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    cv2.imshow('Binary frame', binary_frame)

    if deque.maxlen > len(deque):
        print("Waiting for another frame")
        deque.append(binary_frame)
        continue

    elif deque.maxlen == len(deque) and not avarage_frame_init:
       avaragage_frame = np.mean(np.array(deque, dtype=np.uint8)) 
       avarage_frame_init = True
        
       continue


    cv2.imshow('Avarage frame', avaragage_frame)

    without_backgroung_frame = avaragage_frame - binary_frame

    cv2.imshow('Pict without background', without_backgroung_frame)
    
    erode_frame = cv2.erode(without_backgroung_frame.astype(np.uint8), np.ones((17, 17), np.uint8), iterations=3)
    dilate_frame = cv2.dilate(erode_frame, np.ones((15, 15), np.uint8), iterations=12)


    cv2.imshow('Erode', erode_frame)
    cv2.imshow('Dilate', dilate_frame)


    countour_frame = cv2.findContours(dilate_frame, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    cv2.imshow('Output with contours',cv2.drawContours(dframe , countour_frame[1], -1, (0,255,0),3))
   
    #warning I do not check how avarage behaves, but it works :-)
    avaragage_frame = (avaragage_frame + binary_frame)/2

    if cv2.waitKey(5) & 0xFF == ord('q'):
        break







